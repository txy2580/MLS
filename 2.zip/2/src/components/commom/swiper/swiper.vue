<template>
	<div class="swiper-lun">
	</div>
</template>

<script>
	export default{
		name:'swiper'
	}
</script>

<style>
	.swiper-lun{
		height:300px;
	}
	 
	</style>
