<template>
	<div>
		<h2>我是分类</h2>
	</div>
</template>

<script>
	export default{
		name:"fenlei"
	}
</script>
