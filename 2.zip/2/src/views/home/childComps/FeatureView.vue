<!-- tupian -->
<template>
	<div class="feature">
		<a href="">
			<img src="@/assets/img/feature.jpg" alt="">
		</a>
	</div>
</template>

<script>
	export default{
		name:"FeatureView"
	}
</script>

<style>
	.feature{
		height:170px;
		width:100%;
		margin-top: 7px;;
	}
	.feature img{
		height:170px;
		width:100%;
	}
</style>
