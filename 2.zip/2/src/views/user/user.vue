<template>
	<div>
		<h2>我是用户界面</h2>
	</div>
</template>

<script>
	export default{
		name:"user"
	}
</script>
